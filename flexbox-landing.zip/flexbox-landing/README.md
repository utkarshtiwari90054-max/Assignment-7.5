# Flowly - Flexbox Mini-Project (Assignment 7.5)

A responsive landing page built with HTML and CSS Flexbox.

Sections: navigation bar, hero, 3 feature cards, call-to-action, footer.

Files: `index.html`, `style.css`. Open `index.html` in a browser to view it.
